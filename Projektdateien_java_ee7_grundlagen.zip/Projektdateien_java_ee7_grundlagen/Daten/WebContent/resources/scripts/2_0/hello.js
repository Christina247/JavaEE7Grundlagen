function sayHello() {
	alert("Hallo, Du schöne Welt!");
}