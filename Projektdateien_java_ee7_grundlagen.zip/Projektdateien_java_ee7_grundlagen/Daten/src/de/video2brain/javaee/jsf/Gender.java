package de.video2brain.javaee.jsf;

public enum Gender {

	Male,
	Female,
	SomethingElse
	
}
