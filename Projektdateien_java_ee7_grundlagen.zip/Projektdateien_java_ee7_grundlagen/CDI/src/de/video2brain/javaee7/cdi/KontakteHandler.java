package de.video2brain.javaee7.cdi;

import java.util.List;

public interface KontakteHandler {

	public abstract List<String> getKontakteNamen();

}